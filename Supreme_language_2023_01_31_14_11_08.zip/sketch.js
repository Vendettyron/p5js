function setup() {
  createCanvas(800, 600);
}

function draw() {
  n=0;
  background(191,246,241);
  //cuadrado exterior
  fill(141,149,149);
  square(280,50,300);
  
  //cuadrado interior
  fill(7,227,252);
  square(300,70,260);
  
  //teclado
  fill(0,0,0);
  rect(235,350,400,150);
  
  //teclas
  fill(255,255,255);
  rect(245,360,375,125);
  
  // lineass teclas
  
  //lineas verticales
  fill(255,255,255);
  n=255
  for(i=0;i<39;i++){
   
    line(n,360,n,500);
     n+=10
  }
  
  //lineas horizontales
  fill(255,255,255);
  n=370
  for(i=0;i<13;i++){
   
    line(240,n,625,n);
     n+=10
  }
  
  // case
  fill(141,149,149);
  rect(50,100,150,400);
  
  //sol
   fill(255,255,0);
  circle(525,125,60);
  
}